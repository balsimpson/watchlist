## Watchlist Chrome Extension

Save Movies and TV Shows you find on the page to a personal watchlist.